//
//  FCMWrapper.h
//  FCMPushNotificationWrapper
//
//  Created by 1795068 on 04/01/23.
//

#import <UIKit/UIKit.h>

#ifndef FCMWrapper_h
#define FCMWrapper_h

@interface CustomFCM : NSObject{
    BOOL kAppForeGroundiOS;
}

- (void) registerRemoteNotification;
- (void) subscribeToTopic:(nonnull NSString *)topic;
- (void) unSubscribeFromTopic:(nonnull NSString *)topic;

@end

#endif /* FCMWrapper_h */
