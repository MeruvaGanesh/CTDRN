//
//  CustomFCMProxy.h
//  CustomPushNotification
//
//  Created by 1795068 on 10/01/23.
//


#import <UserNotifications/UserNotifications.h>
#import "Firebase.h"
#import "CustomFCM.h"

#ifndef CustomFCMProxy_h
#define CustomFCMProxy_h

@interface CustomFCMProxy : CustomFCM <UNUserNotificationCenterDelegate, FIRMessagingDelegate>

@end

#endif /* CustomFCMProxy_h */
