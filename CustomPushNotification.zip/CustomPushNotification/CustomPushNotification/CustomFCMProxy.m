//
//  CustomFCMProxy.m
//  CustomPushNotification
//
//  Created by 1795068 on 10/01/23.
//

#import <Foundation/Foundation.h>
#import "CustomFCMProxy.h"
#import <UserNotifications/UserNotifications.h>
#import "Firebase.h"


@implementation CustomFCMProxy

-(void)registerRemoteNotification {
    
    [FIRApp configure];
    [UNUserNotificationCenter currentNotificationCenter].delegate = self;

    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_9_x_Max) {
        UIUserNotificationType allNotificationTypes =(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge);
        UIUserNotificationSettings *settings =[UIUserNotificationSettings settingsForTypes:allNotificationTypes categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
    else
    {
        // iOS 10 or later
        [UNUserNotificationCenter currentNotificationCenter].delegate = self;
        UNAuthorizationOptions authOptions = UNAuthorizationOptionAlert| UNAuthorizationOptionSound| UNAuthorizationOptionBadge;
        [[UNUserNotificationCenter currentNotificationCenter] requestAuthorizationWithOptions:authOptions completionHandler:^(BOOL granted, NSError * _Nullable error) {
            NSLog(@"Error in push registration  = %@",error);
        }];
                [FIRMessaging messaging].delegate = self;
    }
    [[UIApplication sharedApplication] registerForRemoteNotifications];
}


- (void)subscribeToTopic:(NSString *)topic{
    [[FIRMessaging messaging] subscribeToTopic:topic
                                    completion:^(NSError * _Nullable error) {
      NSLog(@"Subscribed to %@ topic", topic);
    }];
}

- (void)unSubscribeFromTopic:(NSString *)topic{
    [[FIRMessaging messaging] unsubscribeFromTopic:topic
                                    completion:^(NSError * _Nullable error) {
      NSLog(@"Un Subscribed from %@ topic", topic);
    }];
}


//Delegate Implementations

- (void)application:(UIApplication *)application
        didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
        NSLog(@"device Token = %@",deviceToken);
       [FIRMessaging messaging].APNSToken = deviceToken;
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    if (error.code == 3010) {
        NSLog(@"Push notifications are not supported in the iOS Simulator.");
    }
    else {
        NSLog(@"application:didFailToRegisterForRemoteNotificationsWithError: %@", error);
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    if ( application.applicationState == UIApplicationStateInactive || application.applicationState == UIApplicationStateBackground  )
    {
        // opened Application from a push notification when the app was on background or inactiva state
        NSLog(@"Notification Received %@", userInfo);
    }
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler{
    completionHandler(UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionSound | UNNotificationPresentationOptionBanner);
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler{
    UIApplicationState state = [[UIApplication sharedApplication] applicationState];
    if (state == UIApplicationStateBackground || state == UIApplicationStateInactive) {
        // background
        kAppForeGroundiOS = false;
    } else if (state == UIApplicationStateActive) {
        // foreground
        kAppForeGroundiOS = true;
    }
}

- (void)messaging:(FIRMessaging *)messaging didReceiveRegistrationToken:(NSString *)fcmToken {
    NSLog(@"FCM registration token: %@", fcmToken);
    [[NSUserDefaults standardUserDefaults] setObject:@"true" forKey:@"updateFCMToken"];
    [[NSUserDefaults standardUserDefaults] setObject:fcmToken forKey:@"FCMToken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
