//
//  FCMWrapper.m
//  FCMPushNotificationWrapper
//
//  Created by 1795068 on 04/01/23.
//

#import "CustomFCM.h"
#import <CustomPushNotification/CustomFCMProxy.h>

@implementation CustomFCM

-(void)registerRemoteNotification {
    CustomFCMProxy *customFCMProxyObj = [CustomFCMProxy alloc];
    [customFCMProxyObj registerRemoteNotification];
}

- (void)subscribeToTopic:(NSString *)topic{
    CustomFCMProxy *customFCMProxyObj = [CustomFCMProxy alloc];
    [customFCMProxyObj subscribeToTopic:topic];
}

- (void)unSubscribeFromTopic:(NSString *)topic{
    CustomFCMProxy *customFCMProxyObj = [CustomFCMProxy alloc];
    [customFCMProxyObj unSubscribeFromTopic:topic];
}

@end
